<?php
    $conn = mysqli_connect('localhost', 'STEREOOMAN', 'laym12020577', 'login-page') or die('connection failed');
    
?>